﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5
{
    // Разделим класс program, на несколько
    // Перенесем метод тестирования в другой файл.
    partial class Program
    {
        static void Main(string[] args)
        {
            //Test();
            Test2();


            Console.ReadKey();
        }
    }
}
