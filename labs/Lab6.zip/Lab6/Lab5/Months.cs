﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5
{
    /**
     * Определим перечисление, его содержимомое
     * название месяцев.
     */
    enum Months
    {
        January = 1, // Сместим на 1, чтобы от 1 до 12
        February,
        March,
        April,
        May,
        June,
        Jule,
        August,
        September,
        October,
        November,
        December
    }
}
